<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\Response;

class UserPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->role === 'admin';
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, User $model): bool
    {
        return $user->role === 'admin' || $user->id === $model->id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return $user->role === 'admin';
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, User $model): bool
    {
        return $user->role === 'admin' || $user->id === $model->id;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, User $model): bool
    {
        return $user->role === 'admin';
    }

/**
     * Menentukan apakah user bisa memulihkan data (jika pakai SoftDeletes).
     */
    public function restore(User $user, User $model): bool
    {
        // Hanya admin yang bisa merestore data
        return $user->role === 'admin';
    }

    /**
     * Menentukan apakah user bisa menghapus permanen dari database.
     */
    public function forceDelete(User $user, User $model): bool
    {
        // Hanya admin yang bisa menghapus permanen
        return $user->role === 'admin';
    }
}
